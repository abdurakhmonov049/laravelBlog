<x-layouts.main>

    <x-slot:title>
        About Me
    </x-slot:title>

    <x-layouts.navbar>

    </x-layouts.navbar>

    <x-layouts.header>
        About Me
    </x-layouts.header>
    <!-- Main Content-->
    
        
    <main class="mb-4">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <p>I am a Backend
                        developer.
                        I studied the field of
                        programming on my own
                        out of interest and didn’t
                        attend any courses.</p>
                    <p>I haven’t experience, but
                        I participated in projects  
                        with teachers at the
                        university...
                        I can help solve the
                        client’s problems</p>
                        <p> My goal: to create relief
                            for people with different  
                            projects... </p>
                        </div>
                    </div>
                </div>
            </main>
           
</x-layouts.main>
